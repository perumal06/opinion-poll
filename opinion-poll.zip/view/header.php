<head>
    <title>Opinion Poll App</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/jquery.ui.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">

    <script src="../assets/js/lib/jquery.js"></script>
    <script src="../assets/js/lib/jquery.ui.js"></script>
    <script src="../assets/js/lib/bootstrap.min.js"></script>
   
</head>