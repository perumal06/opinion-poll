<?php require_once('session.php'); ?>
<!DOCTYPE html>
<html>

    <?php require_once('header.php'); ?>
    
     <script src="../assets/js/pages/list.js"></script>

    <body>

        <?php require_once('navigation.php'); ?>

        <div class="container">
            <form name="voteForm" id="voteForm" method="post">
                <input type="hidden" name="qustId" id="qustId" value="1">
                <div class="row">
                    <div class="col-md-9">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title">
                                    What is your favourite JavaScript Library?</h3>
                            </div>
                            <div class="panel-body">
                                <ul class="list-group">
                                    <li class="list-group-item">
                                        <div class="checkbox">
                                            <label>
                                                <input checked="" type="radio" name="rdFav" value="1">
                                                Jquery
                                            </label>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="checkbox">
                                            <label>
                                                <input type="radio" name="rdFav" value="2">
                                                Moo Tools
                                            </label>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="checkbox">
                                            <label>
                                                <input type="radio" name="rdFav" value="3">
                                                YUI Library
                                            </label>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="checkbox">
                                            <label>
                                                <input type="radio" name="rdFav" value="4">
                                                Glow
                                            </label>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <div class="panel-footer text-center">
                                <button name="btnVote" id="btnVote" type="button" class="btn btn-primary btn-block btn-sm">Vote</button>                              
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </body>
</html>
