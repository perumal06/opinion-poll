<!DOCTYPE html>
<html>

    <?php require_once('header.php'); ?>
    
    <script src="../assets/js/pages/login.js"></script>

    <body>

        <?php require_once('navigation.php'); ?>

        <div class="container">
            <form class="form-signin" name="loginForm" id="loginForm" method="post">
                <h3 class="form-signin-heading">Sign in</h3>
                <input name="username" id="username" type="text" class="form-control" placeholder="Email address" required autofocus><br>
                <input name="password" id="password" type="password" class="form-control" placeholder="Password" required>				
                <button name="btnlogin" id="btnlogin" value="btnlogin" class="btn btn-lg btn-primary btn-block" type="button">Sign in</button>               
                <div id="logErr" class="alert alert-danger hide" style="margin-top: 20px;"></div>
            </form>
        </div>

    </body>
</html>
