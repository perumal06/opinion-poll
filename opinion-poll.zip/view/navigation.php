<div id="navControl">
    <nav class="navbar navbar-default" role="navigation">
        <a class="navbar-brand" href="#">Opinion Poll App</a>	
   

    <?php if (isset($_SESSION) && isset($_SESSION['name'])) { ?>
        <div class="navbar-text navbar-right">
            <span  style="padding-right:20px;">Signed in as <?php echo ucfirst($_SESSION['name']); ?></span>
            <span><a href="logout.php">Logout</a></span>
        </div>
    <?php } ?>
    </nav>

</div>

