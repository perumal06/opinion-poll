<?php require_once('session.php'); ?>
<!DOCTYPE html>
<html>

    <?php require_once('header.php'); ?>
    <link href="../assets/css/bootstrap-combined.min.css" rel="stylesheet">
    <script src="../assets/js/pages/results.js"></script>

    <body>

        <?php require_once('navigation.php'); ?>

        <div class="container">
            <form name="resultForm" id="resultForm" method="post">
                <input type="hidden" name="qustId" id="qustId" value="1">
                <div class="row">
                    <div class="col-md-9">
                        <h3 class="panel-title">
                            <b>Poll : What is your favourite JavaScript Library?</b></h3><br>
                        <strong>Jquery</strong><span class="pull-right ans-lable-1"></span>
                        <div class="progress progress-danger active">
                            <div class="bar ans-1"></div>
                        </div>
                        <strong> Moo Tools</strong><span class="pull-right ans-lable-2"></span>
                        <div class="progress progress-info active">
                            <div class="bar ans-2"></div>
                        </div>
                        <strong>YUI Library</strong><span class="pull-right ans-lable-3"></span>
                        <div class="progress progress-warning active">
                            <div class="bar ans-3"></div>
                        </div>
                        <strong>Glow</strong><span class="pull-right ans-lable-4"></span>
                        <div class="progress progress-success active">
                            <div class="bar ans-4"></div>
                        </div>


                    </div>

                </div>
                <div class="row">
                    <div class="col-md-2">
                    <a href="list.php"><button name="btnThanks" id="btnThanks" type="button" class="btn btn-primary btn-block btn-sm" style="width:150px; margin-top: 100px;">Back</button></a>
                     </div>
                    
                </div>
            </form>
        </div>

    </body>
</html>
