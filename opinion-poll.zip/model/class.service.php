<?php

define('HOSTNAME', 'localhost');
define('USERNAME', 'root');
define('PASSWORD', '');
define('DATABASE', 'opinion-poll');

class Service {

    public $dblink = 0;

    function __construct() {
        $this->dblink = mysql_connect(HOSTNAME, USERNAME, PASSWORD);
        mysql_select_db(DATABASE);
    }

    function check_login($username, $password) {
        $selusr = "SELECT userid, firstname, lastname FROM tbl_users WHERE username='" . $username . "' AND password='" . $password . "'";
        $resusr = $this->Select($selusr);
        return $resusr;
    }

    function get_question($qt_id) {
        $selrem = "SELECT no_of_attempts FROM  tbl_questions";
        $selrem .= " WHERE question_id = " . $qt_id;
        $resarr = $this->Select($selrem);
        return $resarr;
    }

    function get_answers($qt_id) {
        $selrem = "SELECT * FROM  tbl_answers";
        $selrem .= " WHERE question_id = " . $qt_id;     
        $resarr = $this->Select($selrem);
        return $resarr;
    }

    function update_qus_poll_count($post) {
        $upreminder = "UPDATE tbl_questions SET no_of_attempts=" . $post['opinion_count'] . " WHERE question_id=" . $post['question_id'];
        return $this->Update($upreminder);
    }

    function update_ans_poll_count($post) {
        $upreminder = "UPDATE tbl_answers SET opinion_count=" . $post['opinion_count'] . ", opinion_percentage=" . $post['opinion_percentage'] . " WHERE answer_id=" . $post['answer_id'];
        return $this->Update($upreminder);
    }

    function get_results($qid) {
        $seluser = "SELECT *  FROM tbl_answers where question_id =".$qid;
        $resarr = $this->Select($seluser);
        return $resarr;
    }

    function Insert($sql) {
        $dblink = $this->dblink;
        $result = mysql_query($sql, $dblink);
        if (mysql_error($dblink))
            print mysql_error($dblink);
        return mysql_insert_id($dblink);
    }

    function Update($sql) {
        $dblink = $this->dblink;
        $result = mysql_query($sql, $dblink);
        if (mysql_error($dblink))
            print mysql_error($dblink);
        return true;
    }

    function Select($sql) {
        $dblink = $this->dblink;
        $result = mysql_query($sql, $dblink);
        if (mysql_error($dblink))
            return mysql_error($dblink);
        $grandArr = array();
        if (mysql_num_rows($result) > 0) {
            while ($row = mysql_fetch_assoc($result)) {
                $grandArr[] = $row;
            }
            return $grandArr;
        } else {
            return false;
        }
    }

    function Delete($sql) {
        $dblink = $this->dblink;
        $result = mysql_query($sql, $dblink);
        if (mysql_error($dblink))
            print mysql_error($dblink);
        return mysql_affected_rows($dblink);
    }

    function SanitiseUserInput($input) {
        if (get_magic_quotes_gpc()) {  // Stripslashes
            $input = stripslashes($input);
        }
        $input = trim($input);
        $input = mysql_real_escape_string($input);
        return $input;
    }

}

?>