$(document).ready(function() {
    
    $.post('../controller/service.php?action=list_result', $('form#resultForm').serializeArray(), function(data) {
        if (data.success) {
            $.each(data.response, function(i) {
                $('.ans-lable-'+data.response[i].answer_id).html(data.response[i].opinion_percentage+'%');
                $('.ans-'+data.response[i].answer_id).css('width', data.response[i].opinion_percentage+'%');
            });
        }
    }, 'json');

});