$(document).ready(function() {
    
     $(document).keypress(function(e) {
        if (e.which == 13) {
            $('#btnlogin').focus();
            $('#btnlogin').trigger('click');
            return false;
        }
    });

    $("#btnlogin").click(function() {

        $('#logErr').addClass('hide');

        var username = $('#username').val();
        var password = $('#password').val();

        if (username != '' && password != '') {
            $.post('../controller/service.php?action=login', $('form#loginForm').serializeArray(), function(data) {
                if (data.success) {
                    window.location.replace('../view/list.php');
                } else {
                    $('#logErr').html(data.msg);
                    $('#logErr').removeClass('hide');
                }
            }, 'json');
        } else {
            $('#logErr').html('Please enter username and password');
            $('#logErr').removeClass('hide');
        }

    });

});