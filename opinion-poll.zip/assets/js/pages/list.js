$(document).ready(function() {

    $("#btnVote").click(function() {
        
        $('#btnVote').val('Saving...').attr('disabled');
        
        $.post('../controller/service.php?action=vote', $('form#voteForm').serializeArray(), function(data) {
            if (data.success) {
                
                window.location.replace('../view/result.php');
            } else {
                $('#logErr').html(data.msg);
                $('#logErr').removeClass('hide');
            }
        }, 'json');

    });

});