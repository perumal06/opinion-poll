<?php

session_start();

require_once('../model/class.service.php');

$serobj = new Service();

if (isset($_GET['action']) && $_GET['action'] != '') {

    switch ($_GET['action']) {

        case 'login':

            if (isset($_POST['username']) && isset($_POST['password'])) {
                $res_arr = $serobj->check_login($_POST['username'], $_POST['password']);
                if (is_array($res_arr) && count($res_arr) > 0) {

                    // Set the session 
                    $_SESSION['userid'] = $res_arr[0]['userid'];
                    $_SESSION['name'] = $res_arr[0]['firstname'] . ' ' . $res_arr[0]['lastname'];

                    echo json_encode(array('success' => true, 'msg' => 'Login success', 'response' => $res_arr));
                } else {
                    echo json_encode(array('success' => false, 'msg' => 'Invalid username and password'));
                }
            }

            break;


        case 'list_result':

            // Get the results
            $res_arr = $serobj->get_results($_POST['qustId']);
            echo json_encode(array('success' => true, 'response' => $res_arr));

            break;

        case 'vote':

            // Get the question data
            $qus_arr = $serobj->get_question($_POST['qustId']);

            // Add question poll count
            $qus_poll_count = $qus_arr[0]['no_of_attempts'] + 1;

            // Update Que Poll Count
            $qus_up_arr = array('opinion_count' => $qus_poll_count, 'question_id' => $_POST['qustId']);
            $serobj->update_qus_poll_count($qus_up_arr);


            // Get the answer data
            $ans_arr = $serobj->get_answers($_POST['qustId']);
            if (is_array($ans_arr) && count($ans_arr) > 0) {

                
                foreach ($ans_arr as $k => $v) {

                    // Add answer poll count
                    $ans_poll_count = ($v['answer_id'] == $_POST['rdFav']) ? $ans_arr[$k]['opinion_count'] + 1 : $ans_arr[$k]['opinion_count'];

                    // Calculate Poll Percentage
                    $ans_poll_percentage = round(($ans_poll_count / $qus_poll_count) * 100);

                    // Update Ans Poll Count
                    $ans_up_arr = array('opinion_count' => $ans_poll_count, 'opinion_percentage' => $ans_poll_percentage, 'answer_id' => $v['answer_id']);
  
                    $serobj->update_ans_poll_count($ans_up_arr);
                }
            }


            echo json_encode(array('success' => true, 'msg' => 'Saved Successfully'));



            break;
    }
}
?>