<?php

/**
 * Initialize the project
 *
 * @category	Rout
 * @author      Perumal
 */

if (isset($_SESSION['userid']) && $_SESSION['userid'] != '') {
    header('location:view/list.php');
} else {
    header('location:view/login.php');
}

?>

